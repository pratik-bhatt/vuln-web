<?php
include 'shared/resolve.php';
include 'shared/dblink.php';
?>